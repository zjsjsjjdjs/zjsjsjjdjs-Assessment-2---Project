using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player : BaseAttribute
{
    public float moveSpeed = 5; // 移动速度
    public float runSpeed = 10; // 跑步速度
    public float jumpForce = 5; // 跳跃力度
    public LayerMask groundLayer; // 地面的Layer
    public float groundCheckR = 0.1f; // 地面检测半径
    public Transform groundCheckPos; // 地面检测点
    public float attackWaitTime = 0.5f; // 攻击等待时间
   
    
    private Transform camTr; // 相机的Transform组件
    private Animator _animator; // 动画组件
    private Rigidbody _rigidbody; // 刚体组件
    private bool isGround; // 是否在地面上
    private bool isAttack; // 是否在攻击
    private float _attackWait; // 攻击等待时间
    private float hp;
    
    // Start is called before the first frame update
    void Start()
    {
        camTr = Camera.main.transform; // 获取相机的Transform组件
        _animator = GetComponentInChildren<Animator>(); // 获取动画组件
        _rigidbody = GetComponent<Rigidbody>(); // 获取刚体组件
        hp = maxHp;
        hpSlider.maxValue = maxHp;
        hpSlider.value = hp;
    }

    // Update is called once per frame
    void Update()
    {
        // 如果死亡或者暂停，不执行
        if (hp <= 0 || Time.timeScale == 0)
        {
            return;
        }
        
        Attack(); // 攻击
        Move(); // 移动
        Jump(); // 跳跃
    }

    // 攻击
    private void Attack()
    {
        // 如果在攻击状态、跳跃状态 不能攻击
        bool canNotAttack = _animator.GetCurrentAnimatorStateInfo(0).IsName("Land")||
                          _animator.GetCurrentAnimatorStateInfo(0).IsName("StartJump");
        isAttack = Input.GetKey(KeyCode.Mouse0) && !canNotAttack; // 如果按下鼠标左键，设置为攻击状态

        if (isAttack)
        {
            // 朝向相机正前方
            transform.rotation = Quaternion.LookRotation(Quaternion.Euler(0 , camTr.transform.rotation.eulerAngles.y, 0) * Vector3.forward);
            _attackWait = attackWaitTime;
        }
        _animator.SetBool("Shot", isAttack);
    }
    
    // 移动
    private void Move()
    {
        // 如果在跳跃状态、攻击状态、攻击后摇时间大于0 不能移动
        bool canNotMove = _animator.GetCurrentAnimatorStateInfo(0).IsName("Land")||
                          _animator.GetCurrentAnimatorStateInfo(0).IsName("Shot");

        if (_attackWait > 0)
        {
            _attackWait -= Time.deltaTime;
        }
        
        if (canNotMove || isAttack || _attackWait > 0)
        {
            return;
        }
        
        // 获取水平、垂直轴的值
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");
        Vector3 dir = new Vector3(h, 0, v);
        
       // 是否按下左Shift键 奔跑
        float speed = Input.GetKey(KeyCode.LeftShift) ? runSpeed : moveSpeed;
        // 如果有输入
        if (dir != Vector3.zero)
        {
            // 将输入的方向转换为相机的方向
            transform.rotation =
                Quaternion.LookRotation(Quaternion.Euler(0, camTr.transform.rotation.eulerAngles.y, 0) * dir);
            // 移动
            transform.Translate( transform.forward * speed * Time.deltaTime, Space.World);
        }
        
        _animator.SetBool("Move", dir.sqrMagnitude > 0);
        _animator.SetBool("Run", Input.GetKey(KeyCode.LeftShift));
    }

    // 跳跃
    private void Jump()
    {
        // 判断是否在地面上
        isGround = Physics.CheckSphere(groundCheckPos.position, groundCheckR, groundLayer);
        
        // 如果按下空格键、在地面上 跳跃
        if (Input.GetKeyDown(KeyCode.Space) && isGround)
        {
            _rigidbody.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
        }
        _animator.SetFloat("AccelerationY", _rigidbody.velocity.y);
        _animator.SetBool("IsGround", isGround);
    }

    // 受伤 
    public override bool TakeDamage(float damage)
    {
        if (hp <= 0)
        {
            return false;
        }
        
        // 扣除血量 并更新血条 
        hp -= damage;
        hpSlider.value = hp;
        if (hp <= 0)
        {
            hp = 0;
            _animator.SetTrigger("Die");
        }
        
        return true;
    }
}
