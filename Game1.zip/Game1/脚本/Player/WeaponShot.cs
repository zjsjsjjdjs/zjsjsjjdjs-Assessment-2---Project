using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponShot : MonoBehaviour
{
    public GameObject bulletPrefab; // 子弹预制体
    public Transform bulletSpawnPos; // 子弹生成点
    
    // 发射子弹 动画事件 由角色的攻击动画调用
    public void Shot()
    {
        // 从屏幕中心发射一条射线
        RaycastHit hit;
        Ray ray = Camera.main.ScreenPointToRay(new Vector3(Screen.width / 2, Screen.height / 2, 0));
        if (Physics.Raycast(ray, out hit))
        {
            // 如果击中物体 且距离小于5 则将子弹生成点朝向击中点
            if (Vector3.Distance(hit.point, bulletSpawnPos.position) < 5)
            {
                GameObject bulletObj = Instantiate(bulletPrefab, bulletSpawnPos.position, bulletSpawnPos.rotation);
                bulletObj.transform.rotation = Quaternion.LookRotation((ray.origin + ray.direction * 1000) - bulletSpawnPos.position);
            }
            else // 否则将子弹生成点朝向射线方向
            {
                GameObject bulletObj = Instantiate(bulletPrefab, bulletSpawnPos.position, bulletSpawnPos.rotation);
                bulletObj.transform.rotation = Quaternion.LookRotation(hit.point - bulletSpawnPos.position);
            }
            
            
        }
        else // 如果没有击中物体 则将子弹生成点朝向射线方向
        {
            GameObject bulletObj = Instantiate(bulletPrefab, bulletSpawnPos.position, bulletSpawnPos.rotation);
            bulletObj.transform.rotation = Quaternion.LookRotation((ray.origin + ray.direction * 1000) - bulletSpawnPos.position);
        }
        
        
    }

    // 死亡 动画事件 由角色的死亡动画调用
    public void Die()
    {
        Game.Instance.GameOver(false);
    }
}
