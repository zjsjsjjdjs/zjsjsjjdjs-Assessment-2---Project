using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// 基础属性类
public class BaseAttribute : MonoBehaviour
{
    public float maxHp = 100; // 最大生命值
    public Slider hpSlider; // 血条
    
    // 受到伤害
    public virtual bool TakeDamage(float damage)
    {
        return true;
    }
}
