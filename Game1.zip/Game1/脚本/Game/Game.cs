using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Random = UnityEngine.Random;

public class Game : MonoBehaviour
{
    public static Game Instance; // 单例
    public GameObject winPanel; // 胜利面板
    public GameObject losePanel; // 失败面板
    public float gameTimer = 180; // 游戏计时
    public Text gameTimerText; // 游戏计时文本
    public Text enemyCountText; // 敌人数量文本
    
    public List<Transform> movePosList; // 移动点列表
    private Player _player; // 玩家组件
    private int _enemyCount; // 敌人数量
    private bool over;
    
    private void Awake()
    {
        Instance = this;
    }

    // Start is called before the first frame update
    void Start()
    {
        _enemyCount = GameObject.FindGameObjectsWithTag("Enemy").Length;
        _player = GameObject.FindWithTag("Player").GetComponent<Player>();
        gameTimerText.text = "剩余时间：" + gameTimer.ToString("F2");
        enemyCountText.text = "剩余敌人：" + _enemyCount;
    }

    // Update is called once per frame
    void Update()
    {
        if (over)
        {
            return;
        }
        // 如果按下Esc键，返回主菜单
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Back();
        }

        // 如果暂停，不执行
        if (Time.timeScale == 0)
        {
            return;
        }
        
        // 刷新游戏计时 更新文本 
        gameTimer -= Time.deltaTime;
        gameTimerText.text = "剩余时间：" +  gameTimer.ToString("F2");
        if (gameTimer <= 0) // 如果时间到了，游戏结束
        {
            GameOver(false);
        }
    }
    
    // 获取随机移动点
    public Vector3 GetRandomMovePos()
    {
        return movePosList[Random.Range(0, movePosList.Count)].position;
    }
    
    // 获取玩家位置
    public Vector3 GetPlayerPos()
    {
        return _player.transform.position;
    }
    
    // 游戏结束 isWin：是否胜利
    public void GameOver(bool isWin)
    {
        over = true;
        Time.timeScale = 0;
        if (isWin)
        {
            winPanel.SetActive(true);
        }
        else
        {
            losePanel.SetActive(true);
        }
    }
    
    // 敌人死亡 减少敌人数量 更新文本
    public void EnemyDead()
    {
        _enemyCount--;
        enemyCountText.text = "剩余敌人：" + _enemyCount;
        if (_enemyCount <= 0)
        {
            GameOver(true);
        }
    }
    
    // 重新开始
    public void Restart()
    {
        Time.timeScale = 1;
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
    
    // 返回主菜单
    public void Back()
    {
        Time.timeScale = 1;
        SceneManager.LoadScene(0);
    }
}
