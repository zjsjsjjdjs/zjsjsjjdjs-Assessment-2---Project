using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartSceneManager : MonoBehaviour
{
    // 开始游戏 加载Level1场景
    public void StartGame()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene("Level1");
    }
    
    // 退出游戏
    public void ExitGame()
    {
        Application.Quit();
    }
}
