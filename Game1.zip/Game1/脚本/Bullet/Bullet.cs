using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float speed = 10; // 子弹速度
    public float lifeTime = 5; // 子弹生命周期
    public float damage = 10; // 子弹伤害
    public GameObject hitEffect; // 子弹击中特效
    public GameObject muzzleflash; // 枪口火焰
    public float detectionRadius; // 检测半径
    public string targetTag; // 目标标签
    
    // Start is called before the first frame update
    void Start()
    {
        GameObject muzzleflashObj = Instantiate(muzzleflash, transform.position, transform.rotation);
        Destroy(muzzleflashObj, 0.5f);
        
        Destroy(gameObject, lifeTime); // 一定时间后销毁子弹
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 lastPos = transform.position;
        transform.Translate(Vector3.forward * speed * Time.deltaTime); // 子弹前进
        // 球形检测
        RaycastHit hit;
        if (Physics.SphereCast(lastPos, detectionRadius, transform.position - lastPos, out hit, Vector3.Distance(lastPos, transform.position)))
        {
            // 如果击中物体
            if (hit.collider.CompareTag(targetTag))
            {
                // 如果击中的物体是目标标签 则对其造成伤害
                hit.collider.GetComponent<BaseAttribute>()?.TakeDamage(damage); // 造成伤害
            }
            GameObject hitEffectObj = Instantiate(hitEffect, hit.point, Quaternion.LookRotation(hit.normal));
            Destroy(hitEffectObj, 1); // 生成击中特效
            Destroy(gameObject); // 销毁子弹
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, detectionRadius);
    }
}
