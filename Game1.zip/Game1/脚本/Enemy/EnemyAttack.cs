using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAttack : MonoBehaviour
{
    public float damage; // 伤害
    public float attackAngle; // 攻击角度
    public GameObject hitEffect; // 击中特效
    private bool isRemote; // 是否远程攻击
    private Transform _playerTr; // 玩家的Transform组件
    private float attackDistance = 10; // 攻击距离
    
    public GameObject bulletPrefab; // 子弹预制体
    public Transform bulletSpawnPos; // 子弹生成点
    private Enemy _enemy; // 敌人组件
    void Start()
    {
        _playerTr = GameObject.FindWithTag("Player").transform;
        _enemy = GetComponentInParent<Enemy>();
        attackDistance = _enemy.attackDistance;
        isRemote = _enemy.isRemote;
    }
    
    // 发射子弹 动画事件 由敌人的攻击动画调用
    public void AttackEvent()
    {
        // 如果是远程攻击 则生成子弹
        if (isRemote)
        {
            GameObject bulletObj = Instantiate(bulletPrefab, bulletSpawnPos.position, bulletSpawnPos.rotation);
            
        }
        else // 如果是近战攻击 则判断玩家是否在攻击范围内
        {
            // 判断玩家是否在攻击范围内
            Vector3 dir = _playerTr.position - transform.position;
            dir.y = 0;
            if (Vector3.Angle(transform.parent.forward, dir) < attackAngle && Vector3.Distance(transform.position, _playerTr.position) <= attackDistance)
            {
                // 如果玩家在攻击范围内 则对玩家造成伤害 并生成击中特效
                bool ishit = _playerTr.GetComponent<Player>().TakeDamage(damage);
                if (ishit)
                {
                    GameObject hitEffectObj = Instantiate(hitEffect, _playerTr.position, Quaternion.LookRotation(dir));
                    Destroy(hitEffectObj, 1); // 生成击中特效
                }
            }
        }
    }
}
