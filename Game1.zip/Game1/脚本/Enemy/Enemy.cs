using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;

public class Enemy : BaseAttribute
{
    public float attackWaitTime = 0.5f; // 攻击等待时间
    public float attackDistance = 10; // 攻击距离
    public float moveWaitTime = 5; // 移动等待时间
    public Text hpText; // 血量文本
    public bool isRemote;
    
    private Animator _animator; // 动画组件
    private NavMeshAgent _meshAgent; // 导航组件
    private bool _isAttackState; // 是否在攻击
    private Vector3 _targetPos; // 目标点
    private float _moveWait; // 移动等待时间
    private float _attackWait; // 攻击等待时间
    private float hp; // 当前生命值
    
    // Start is called before the first frame update
    void Start()
    {
        _animator = GetComponentInChildren<Animator>();
        _meshAgent = GetComponent<NavMeshAgent>();
        _targetPos = Game.Instance.GetRandomMovePos();
        
        hp = maxHp;
        hpSlider.maxValue = maxHp;
        hpSlider.value = hp;
        hpText.text = hp + "/" + maxHp;
    }

    // Update is called once per frame
    void Update()
    {
        // 血条始终朝向摄像机
        hpSlider.transform.LookAt(Camera.main.transform);
        if (hp <= 0 || Time.timeScale == 0)
        { 
            return;
        }
        // 如果在攻击状态
        if (_isAttackState)
        {
            // 是否在进行攻击
            bool isAttack = _animator.GetCurrentAnimatorStateInfo(0).IsName("Attack");
            if (isAttack)
            {
                return;
            }

            // 如果玩家距离大于攻击距离 则追击玩家
            if (Vector3.Distance(transform.position, Game.Instance.GetPlayerPos()) > attackDistance)
            {
                SetDestinationByPlayer();
                return;
            }
            else // 如果玩家距离小于攻击距离 则攻击玩家
            {
                // 如果是远程攻击 则判断玩家是否在攻击范围内 如果是近战攻击 则直接攻击
                if (isRemote)
                {
                    // 射线检测与玩家之间是否有障碍物 如果有障碍物 则追击玩家 如果没有障碍物 则攻击玩家
                    RaycastHit hit;
                    if (Physics.Raycast(transform.position, Game.Instance.GetPlayerPos() - transform.position, out hit, Vector3.Distance(transform.position, Game.Instance.GetPlayerPos())))
                    {
                        if (hit.collider.CompareTag("Player"))
                        {
                            Attack(); 
                        }
                        else
                        {
                            SetDestinationByPlayer();
                        }
                    }
                    else
                    {
                        SetDestinationByPlayer();
                    }
                }
                else
                {
                    Attack();
                }
                
            }
            
        }else{
            // 如果玩家距离小于攻击距离 则进入攻击状态
            if (Vector3.Distance(transform.position, Game.Instance.GetPlayerPos()) <= attackDistance)
            {
                _isAttackState = true;
                _animator.SetBool("Move", false);
                return;
            }
            
            // 如果到达目标点 停止移动
            if (Vector3.Distance(_targetPos, transform.position) < 1)
            {
                _meshAgent.isStopped = true;
                _animator.SetBool("Move", false);
            }

            // 如果移动等待时间大于0 则减少移动等待时间
            if (_moveWait > 0)
            {
                _moveWait -= Time.deltaTime;
            }
            else
            {
                // 否则随机获取一个移动点
                _targetPos = Game.Instance.GetRandomMovePos();
                _meshAgent.SetDestination(_targetPos);
                _meshAgent.isStopped = false;
                _moveWait = moveWaitTime;
                _animator.SetBool("Move", true);
            }
        }
    }

    // 攻击
    private void Attack()
    {
        // 停止移动 判断是否满足攻击间隔时间 播放攻击动画
        _meshAgent.isStopped = true;
        _animator.SetBool("Move", false);
        if (_attackWait > 0)
        {
            _attackWait -= Time.deltaTime;
        }
        else
        {
            Vector3 dir = Game.Instance.GetPlayerPos() - transform.position;
            dir.y = 0;
            transform.forward = dir.normalized;
            _animator.SetTrigger("Attack");
            _attackWait = attackWaitTime;
        }
    }
    
    // 设置目标点为玩家位置
    private void SetDestinationByPlayer()
    {
        _meshAgent.SetDestination(Game.Instance.GetPlayerPos());
        _meshAgent.isStopped = false;
        _animator.SetBool("Move", true);
    }
    
    // 受到伤害 
    public override bool TakeDamage(float damage)
    {
        if (!_isAttackState)
        {
            _isAttackState = true;
        }
        if (hp <= 0)
        {
            return true;
        }
        // 扣除血量 并更新血条 并更新血条文本
        hp -= damage;
        hp = Mathf.Clamp(hp,0, maxHp);
        hpSlider.value = hp;
        hpText.text = hp + "/" + maxHp;
        if (hp <= 0)
        {
            hp = 0;
            _meshAgent.isStopped = true;
            _animator.SetTrigger("Die");
            Game.Instance.EnemyDead(); // 敌人死亡 减少敌人数量 更新文本
            Destroy(gameObject, 3);
        }

        return true;
    }

}
