using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform targetTr; // 跟随的目标
    public Vector3 offset; // 相机与目标的偏移量
    public Vector3 offsetAngleSpeed; // 相机与目标的偏移旋转速度
    public Vector2 limitAngle; // 相机与目标的偏移旋转角度限制
    private Vector3 _offsetAngle; // 相机与目标的偏移旋转量
    private float _distance; // 相机与目标的距离
    
    // Start is called before the first frame update
    void Start()
    {
        transform.position = targetTr.position + offset;
        transform.LookAt(targetTr);
        _offsetAngle = Quaternion.LookRotation(offset).eulerAngles;
        _distance = offset.magnitude;
    }

    private void Update()
    {
        // 获取鼠标滑动的值 改变 相机与目标的偏移旋转量的旋转值
        _offsetAngle += new Vector3(Input.GetAxis("Mouse Y") * offsetAngleSpeed.y, Input.GetAxis("Mouse X") * offsetAngleSpeed.x, 0) * Time.deltaTime;
        // 限制相机上下旋转角度
        _offsetAngle.x = Mathf.Clamp(_offsetAngle.x, limitAngle.x, limitAngle.y);
        
        // 根据相机与目标的偏移旋转量 计算相机与目标的偏移量
        offset = Quaternion.Euler(_offsetAngle) * Vector3.forward * _distance;
        
        // 相机的位置 = 目标的位置 + 相机与目标的偏移量
        Vector3 targetPos = targetTr.position + offset;
        
        // 射线检测 相机与目标之间是否有障碍物
        RaycastHit hitInfo;
        if (Physics.Linecast(targetTr.position, targetPos, out hitInfo))
        {
            // 如果有障碍物，相机的位置就是障碍物的位置
            targetPos = hitInfo.point;
        }
        transform.position = targetPos;
        transform.LookAt(targetTr.position);
    }
}
